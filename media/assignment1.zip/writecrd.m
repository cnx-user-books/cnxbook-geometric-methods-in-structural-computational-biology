function writecrd(A,filename)
   [r,c]=size(A);
   natom = r/3;
   outid=fopen(filename,'w');
   fprintf(outid,'%g atoms\n', [natom]);
   fprintf(outid,'%8.3f\n',[A]);
